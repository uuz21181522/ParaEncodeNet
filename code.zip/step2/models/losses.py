import torch._utils
try:
	torch._utils._rebuild_tensor_v2
except AttributeError:
	def _rebuild_tensor_v2(storage, storage_offset, size, stride, requires_grad, backward_hooks):
		tensor = torch._utils._rebuild_tensor(storage, storage_offset, size, stride)
		tensor.requires_grad = requires_grad
		tensor._backward_hooks = backward_hooks
		return tensor
	torch._utils._rebuild_tensor_v2 = _rebuild_tensor_v2

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init
import functools
import torch.autograd as autograd
import numpy as np
import torchvision.models as models
import util.util as util
from torch.autograd import Variable
import pdb
import matplotlib.pylab as pl
import os
###############################################################################
# Functions
###############################################################################

class PerceptualLoss():
	def contentFunc(self):
		conv_3_3_layer = 14
		cnn = models.vgg19()
		pre = torch.load(os.path.join(r'E:\dragon\code\restored\restored16', 'vgg19-dcbb9e9d.pth'))
		cnn.load_state_dict(pre)
		cnn = cnn.features
		cnn = cnn.cuda()
		model = nn.Sequential()
		model = model.cuda()
		print('********************************')
		for i,layer in enumerate(list(cnn)):
			model.add_module(str(i),layer)
			if i == conv_3_3_layer:
				break
		return model

	def initialize(self, loss):
		self.criterion = loss
		self.contentFunc = self.contentFunc()
			
	def get_loss(self, fakeIm, realIm):
		f_fake = self.contentFunc.forward(fakeIm) 
		f_real = self.contentFunc.forward(realIm)
		f_real_no_grad = f_real.detach()
		loss = self.criterion(f_fake, f_real_no_grad)
		return loss

	def get_mseloss(self, fakeIm, realIm):
		loss_fn = nn.MSELoss(reduction='sum')
		loss = loss_fn(fakeIm, realIm.detach())
		return loss
	
	def get_l1loss(self, latent_i, latent_t):
		L1_loss = nn.L1Loss(reduction='sum')
		output = L1_loss(latent_i, latent_t.detach())
		return output

	def get_tripletloss(self, inputs, targets, margin=0.3):

		"""
		Args:
			inputs (torch.Tensor): feature matrix with shape (batch_size, feat_dim).
			targets (torch.LongTensor): ground truth labels with shape (num_classes).
		"""
		ranking_loss = nn.MarginRankingLoss(margin=margin)

		n = inputs.size(0)

		# Compute pairwise distance, replace by the official when merged
		dist = torch.pow(inputs, 2).sum(dim=1, keepdim=True).expand(n, n)
		dist = dist + dist.t()
		dist.addmm_(1, -2, inputs, inputs.t())
		dist = dist.clamp(min=1e-12).sqrt()  # for numerical stability

		# For each anchor, find the hardest positive and negative
		mask = targets.expand(n, n).eq(targets.expand(n, n).t())
		dist_ap, dist_an = [], []
		for i in range(n):
			dist_ap.append(dist[i][mask[i]].max().unsqueeze(0))
			dist_an.append(dist[i][mask[i] == 0].min().unsqueeze(0))
		dist_ap = torch.cat(dist_ap)
		dist_an = torch.cat(dist_an)

		# Compute ranking hinge loss
		y = torch.ones_like(dist_an)
		return ranking_loss(dist_an, dist_ap, y)


	def get_tripletloss2(self, inputs, targets, margin=0.3):

		"""
		Args:
			inputs (torch.Tensor): feature matrix with shape (batch_size, feat_dim).
			targets (torch.LongTensor): ground truth labels with shape (num_classes).
		"""
		ranking_loss = nn.MarginRankingLoss(margin=margin)

		n = inputs.size(0)

		# Compute pairwise distance, replace by the official when merged
		dist = torch.pow(inputs, 2).sum(dim=1, keepdim=True).expand(n, n)
		dist = dist + dist.t()
		dist.addmm_(1, -2, inputs, inputs.t())
		dist = dist.clamp(min=1e-12).sqrt()  # for numerical stability

		# For each anchor, find the hardest positive and negative
		mask = targets.expand(n, n).eq(targets.expand(n, n).t())

		loss = 0
		for i in range(n):
			loss += max(0, dist[i][mask[i]].max()-dist[i][mask[i]==0].min()+margin)
			#loss += dist[i][mask[i]].max()
		return loss



	def get_nceloss2(self, latent_i, latent_t, encodeings):
		latent_t=latent_t[encodeings]
		z_i = latent_i
		z_j = latent_t
		#print("A:", z_i)
		#print("B:", z_j)

		#z_i = F.normalize(latent_i, dim=1)
		#z_j = F.normalize(latent_t, dim=1)

		similarity_matrix = F.cosine_similarity(z_i, z_j, dim=1)

		loss = -similarity_matrix.exp().sum().log()
		#loss = self.get_l1loss(z_i, z_j)

		return loss, torch.zeros(1), torch.zeros(1)

	def get_nceloss999(self, latent_i, latent_t, encodeings):
		if latent_i.isnan().any():
			print("latent_i")

		numerator = 0
		denominator = 0
		embeedings_num = latent_t.shape[0]


		z_i = F.normalize(latent_i, dim=1)
		z_j = F.normalize(latent_t, dim=1)
		#z_i = latent_i
		#z_j = latent_t


		z_i_mean = torch.zeros_like(latent_t)
		for i in range(0, embeedings_num):
			K = (encodeings==i).sum()
			if K > 0:
				z_i_mean[i] = (z_i[torch.nonzero(encodeings==i)]).mean(dim=0)


		#similarity_matrix = F.cosine_similarity(z_i_mean.unsqueeze(1), z_j.unsqueeze(0), dim=2)
		similarity_matrix = torch.zeros([embeedings_num, embeedings_num])

		for i in range(0, embeedings_num):
			numerator += 2*(self.get_l1loss(z_i_mean[i], z_j[i])).exp().log()

			negatives_ij = self.get_l1loss(z_i_mean[i].repeat(), z_j)
			negatives_ij[i] = 0
			denominator += negatives_ij.exp().sum().log()

			negatives_ji = similarity_matrix[i, :]
			negatives_ji[i] = 0
			denominator += negatives_ji.exp().sum().log()


		loss = (denominator - numerator)/embeedings_num

		return loss, numerator, denominator


	def get_nceloss3(self, latent_i, latent_t, encodeings):
		if latent_i.isnan().any():
			print("latent_i")

		z_i = F.normalize(latent_i, dim=1)
		z_j = F.normalize(latent_t, dim=1)


		similarity_matrix = F.cosine_similarity(z_i.unsqueeze(1), z_j.unsqueeze(0), dim=2)
		batch_size = int(z_i.shape[0])

		#numerator = torch.diag(similarity_matrix).exp().log().sum()

		numerator = 0
		denominator = 0
		embeedings_num = latent_t.shape[0]
		K = torch.zeros(embeedings_num)

		for i in range(0, embeedings_num):
			negatives = similarity_matrix[:, i]*(encodeings!=i)
			denominator += negatives.exp().sum().log()


		for i in range(0, batch_size):
			numerator += similarity_matrix[i, encodeings[i]].exp().log()
			negatives = similarity_matrix[i, :]
			negatives[encodeings[i]]=0
			denominator += negatives.exp().sum().log()



		loss = (denominator - numerator)/batch_size

		return loss, numerator, denominator

	def get_nceloss1(self, latent_i, latent_t, labels):
		self.SupConLoss = SupConLoss()
		features = torch.cat([latent_i.unsqueeze(1), latent_t.unsqueeze(1)], dim=1)
		loss = self.SupConLoss(features, labels)
		return loss, torch.zeros(1), torch.zeros(1)

	def get_nceloss(self, latent_i, latent_t, labels):
		return torch.zeros(1), torch.zeros(1), torch.zeros(1)


class SupConLoss(nn.Module):
	"""Supervised Contrastive Learning: https://arxiv.org/pdf/2004.11362.pdf.
	It also supports the unsupervised contrastive loss in SimCLR"""
	def __init__(self, temperature=1.0, contrast_mode='all',
				base_temperature=1.0):
		super(SupConLoss, self).__init__()
		self.temperature = temperature
		self.contrast_mode = contrast_mode
		self.base_temperature = base_temperature

	def forward(self, features, labels=None, mask=None):
		"""Compute loss for model. If both `labels` and `mask` are None,
		it degenerates to SimCLR unsupervised loss:
		https://arxiv.org/pdf/2002.05709.pdf
		Args:
			features: hidden vector of shape [bsz, n_views, ...].
			labels: ground truth of shape [bsz].
			mask: contrastive mask of shape [bsz, bsz], mask_{i,j}=1 if sample j
				has the same class as sample i. Can be asymmetric.
		Returns:
			A loss scalar.
		"""
		device = (torch.device('cuda')
				if features.is_cuda
				else torch.device('cpu'))

		if len(features.shape) < 3:
			raise ValueError('`features` needs to be [bsz, n_views, ...],'
							'at least 3 dimensions are required')
		if len(features.shape) > 3:
			features = features.view(features.shape[0], features.shape[1], -1)

		batch_size = features.shape[0]
		if labels is not None and mask is not None:
			raise ValueError('Cannot define both `labels` and `mask`')
		elif labels is None and mask is None:
			mask = torch.eye(batch_size, dtype=torch.float32).to(device)
		elif labels is not None:
			labels = labels.contiguous().view(-1, 1)
			if labels.shape[0] != batch_size:
				raise ValueError('Num of labels does not match num of features')
			mask = torch.eq(labels, labels.T).float().to(device)
		else:
			mask = mask.float().to(device)

		contrast_count = features.shape[1]
		contrast_feature = torch.cat(torch.unbind(features, dim=1), dim=0)
		if self.contrast_mode == 'one':
			anchor_feature = features[:, 0]
			anchor_count = 1
		elif self.contrast_mode == 'all':
			anchor_feature = contrast_feature
			anchor_count = contrast_count
		else:
			raise ValueError('Unknown mode: {}'.format(self.contrast_mode))

		# compute logits
		anchor_dot_contrast = torch.div(
			torch.matmul(anchor_feature, contrast_feature.T),
			self.temperature)
		# for numerical stability
		logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
		logits = anchor_dot_contrast - logits_max.detach()

		# tile mask
		mask = mask.repeat(anchor_count, contrast_count)
		# mask-out self-contrast cases
		logits_mask = torch.scatter(
			torch.ones_like(mask),
			1,
			torch.arange(batch_size * anchor_count).view(-1, 1).to(device),
			0
		)
		mask = mask * logits_mask

		# compute log_prob
		exp_logits = torch.exp(logits) * logits_mask
		log_prob = logits - torch.log(exp_logits.sum(1, keepdim=True))

		# compute mean of log-likelihood over positive
		mean_log_prob_pos = (mask * log_prob).sum(1) / mask.sum(1)

		# loss
		loss = - (self.temperature / self.base_temperature) * mean_log_prob_pos
		loss = loss.view(anchor_count, batch_size).mean()

		return loss



def init_loss(opt, tensor):
	ae_loss = None
	content_loss = None
	
	content_loss = PerceptualLoss()
	content_loss.initialize(nn.MSELoss())
	
	return content_loss


"""
	def get_nceloss(self, latent_i, latent_t, encodeings):
		if latent_i.isnan().any():
			print("latent_i")

		z_i = F.normalize(latent_i, dim=1)
		z_j = F.normalize(latent_t, dim=1)

		similarity_matrix = F.cosine_similarity(z_i.unsqueeze(1), z_j.unsqueeze(0), dim=2)
		batch_size = int(z_i.shape[0])

		#numerator = torch.diag(similarity_matrix).exp().log().sum()

		numerator = 0
		denominator = 0
		K = torch.tensor(np.array(batch_size, dtype=float)).log()


		for i in range(0, batch_size):
			numerator += similarity_matrix[i, encodeings[i]].exp().log()
			negatives = similarity_matrix[i, :]
			negatives[encodeings[i]]=0
			denominator += negatives.exp().sum().log()

		loss = (denominator - numerator)/batch_size

		return loss, numerator, denominator
"""



"""
import torch._utils
try:
	torch._utils._rebuild_tensor_v2
except AttributeError:
	def _rebuild_tensor_v2(storage, storage_offset, size, stride, requires_grad, backward_hooks):
		tensor = torch._utils._rebuild_tensor(storage, storage_offset, size, stride)
		tensor.requires_grad = requires_grad
		tensor._backward_hooks = backward_hooks
		return tensor
	torch._utils._rebuild_tensor_v2 = _rebuild_tensor_v2

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init
import functools
import torch.autograd as autograd
import numpy as np
import torchvision.models as models
import util.util as util
from torch.autograd import Variable
import pdb
import matplotlib.pylab as pl
import ot
###############################################################################
# Functions
###############################################################################

class PerceptualLoss():
	def contentFunc(self):
		conv_3_3_layer = 14
		cnn = models.vgg19()
		pre = torch.load('/share2/data/AONLOS/Dataset/TrainedWeight/'+'vgg19-dcbb9e9d.pth')
		cnn.load_state_dict(pre)
		cnn = cnn.features
		cnn = cnn.cuda()
		model = nn.Sequential()
		model = model.cuda()
		print('********************************')
		for i,layer in enumerate(list(cnn)):
			model.add_module(str(i),layer)
			if i == conv_3_3_layer:
				break
		return model

	def initialize(self, loss):
		self.criterion = loss
		self.contentFunc = self.contentFunc()
			
	def get_loss(self, fakeIm, realIm):
		f_fake = self.contentFunc.forward(fakeIm) 
		f_real = self.contentFunc.forward(realIm)
		f_real_no_grad = f_real.detach()
		loss = self.criterion(f_fake, f_real_no_grad)
		return loss

	def get_mseloss(self, fakeIm, realIm):
		loss_fn = nn.MSELoss(reduction='sum')
		loss = loss_fn(fakeIm, realIm.detach())
		return loss
	
	def get_l1loss(self, latent_i, latent_t):
		L1_loss = nn.L1Loss(reduction='sum')
		output = L1_loss(latent_i, latent_t.detach())
		return output

	def get_otloss(self, latent_i, latent_t):
		batchsize = latent_i.shape[0]
		M = torch.zeros(batchsize,batchsize)
		M_metric = nn.L1Loss(reduction='sum')
		for ii in range(0, batchsize):
			for jj in range(0, batchsize):
				if ii == jj:
					M[ii,jj] = M_metric(latent_i[ii], latent_t[jj].detach())
				else:
					M[ii,jj] = 10e10
		aa = torch.ones([batchsize, ])
		bb = torch.ones((batchsize, ))
		# require ot.__version__ >= 0.8.0
		gamma = ot.emd(aa, bb, M)
		loss_ot = torch.sum(gamma*M).cuda()
		return loss_ot

	def get_nceloss(self, latent_i, latent_t):
		#loss = self.get_l1loss(latent_i, latent_t).log().sum()
		latent_i = latent_i.permute(0, 2, 3, 1).contiguous()
		latent_i = latent_i.view(-1, latent_i.size(3))
		latent_t = latent_t.permute(0, 2, 3, 1).contiguous()
		latent_t = latent_t.view(-1, latent_t.size(3))

		z_i = F.normalize(latent_i, dim=1)
		z_j = F.normalize(latent_t, dim=1)
		representations = torch.cat([z_i, z_j], dim=0)
		similarity_matrix = F.cosine_similarity(representations.unsqueeze(1), representations.unsqueeze(0), dim=2)

		batch_size = int(z_i.shape[0])


		loss = 0
		numerator = 0
		denominator = 0
		for i in range(0, batch_size):
			loss_ij, numerator_ij, denominator_ij = f(i, i + batch_size, similarity_matrix, batch_size)
			loss += loss_ij
			numerator += numerator_ij
			denominator += denominator_ij

			loss_ij, numerator_ij, denominator_ij = f(i + batch_size, i, similarity_matrix, batch_size)
			loss += loss_ij
			numerator += numerator_ij
			denominator += denominator_ij

		loss = loss / (2.0 * batch_size)
		print(loss)
		return loss, numerator, denominator

def f(i, j, similarity_matrix, batch_size):
		temperature = 0.07
		numerator = torch.exp(similarity_matrix[i, j] / temperature)
		denominator = torch.sum(torch.exp(similarity_matrix[i, :] / temperature)) - torch.exp(
			similarity_matrix[i, i] / temperature)
		denominator = denominator/batch_size
		return torch.log(denominator)-torch.log(numerator), torch.log(numerator), torch.log(denominator)

def init_loss(opt, tensor):
	ae_loss = None
	content_loss = None
	
	content_loss = PerceptualLoss()
	content_loss.initialize(nn.MSELoss())
	
	return content_loss
"""